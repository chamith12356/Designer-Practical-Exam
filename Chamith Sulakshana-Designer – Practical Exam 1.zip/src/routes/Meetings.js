import React from "react";
import Header from "../components/Header"; // Adjusted import path
import Navbar from "../components/Navbar";
function Meetings() {
  return (
    <div>
      <Header />
      <Navbar />
      <h1>Meetings page</h1>
    </div>
  );
}

export default Meetings;
