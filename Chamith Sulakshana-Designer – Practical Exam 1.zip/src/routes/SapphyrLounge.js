import React from "react";
import Header from "../components/Header"; // Adjusted import path
import Navbar from "../components/Navbar";
function SapphyrLounge() {
  return (
    <div>
      <Header />
      <Navbar />
      <h1>SapphyrLounge page</h1>
    </div>
  );
}

export default SapphyrLounge;
