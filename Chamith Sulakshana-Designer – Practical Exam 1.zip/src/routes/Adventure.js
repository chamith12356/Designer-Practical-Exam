import React from "react";
import Header from "../components/Header"; // Adjusted import path
import Navbar from "../components/Navbar";
function Adventure() {
  return (
    <div>
      <Header />
      <Navbar />
      <h1>Adventure page</h1>
    </div>
  );
}

export default Adventure;
