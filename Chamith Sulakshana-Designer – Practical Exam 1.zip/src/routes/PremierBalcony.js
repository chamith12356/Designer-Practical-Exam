import React from "react";
import Header from "../components/Header"; // Adjusted import path
import Navbar from "../components/Navbar";
function PremierBalcony() {
  return (
    <div>
      <Header />
      <Navbar />
      <h1>PremierBalcony page</h1>
    </div>
  );
}

export default PremierBalcony;
