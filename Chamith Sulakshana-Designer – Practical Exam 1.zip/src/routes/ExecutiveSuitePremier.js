import React from "react";
import Header from "../components/Header"; // Adjusted import path
import Navbar from "../components/Navbar";
function ExecutiveSuitePremier() {
  return (
    <div>
      <Header />
      <Navbar />
      <h1>ExecutiveSuitePremier page</h1>
    </div>
  );
}

export default ExecutiveSuitePremier;
