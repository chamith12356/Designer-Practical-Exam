import React, { useState } from "react";
import "./NavbarStyle.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import { Link } from "react-router-dom";

import SubLinks from "./SubLinks";
const NavbarData = [
  {
    title: "ABOUT",
    links: [
      {
        title1: "About The Hotel",
        subLinks: [
          { title: "Overview", url: "/about/Overview" },
          {
            title: "Explore Colombo",
            url: "/about/local-guide",
          },
          {
            title: "Services & Facilities",
            url: "/about/services-facilities",
          },
          {
            title: "Map & Directions",
            url: "/about/map",
          },
        ],
      },
    ],
  },
  {
    title: "ROOMS ",
    links: [
      {
        title1: "Rooms",
        subLinks: [
          {
            title: "Deluxe Lake View",
            url: "/deluxe-lake-view-room",
          },
          {
            title: "Deluxe Ocean View",
            url: "/deluxe-ocean-view-room",
          },
          {
            title: "Premier Balcony",
            url: "/premier-balcony-room",
          },
          {
            title: "Premier Ocean View",
            url: "/premier-ocean-view-room",
          },
        ],
      },
      {
        title1: "Horizon Club",
        subLinks: [
          {
            title: "Horizon Club Lake View",
            url: "/horizonlake-view",
          },
          {
            title: "Horizon Club Ocean View",
            url: "/horizonocean-view",
          },
        ],
      },
      {
        title1: "Suites",
        subLinks: [
          {
            title: "Executive Suites",
            url: "/executive-suites",
          },
          {
            title: "Specialty Suites",
            url: "/specialty-suites",
          },
          {
            title: "Shangri-La Suite",
            url: "/shangrila-suite",
          },
        ],
      },
      {
        title1: "Connecting Rooms",
        subLinks: [
          {
            title: "Executive Suite & Premier Ocean Room Connecting",
            url: "/executive-suite",
          },
          {
            title: "Two Deluxe Lake View Rooms Connecting",
            url: "/two-deluxe-lake",
          },
        ],
      },
    ],
  },
  {
    title: "DINING",
    links: [
      {
        title1: "Restaurants",
        subLinks: [
          {
            title: "Cake Temptations by Shangri-La Colombo",
            url: "/cake-temptations",
          },
          {
            title: "Shang Palace",
            url: "/shang-palace",
          },
          {
            title: "Capital Bar & Grill",
            url: "/capital-bar",
          },
          {
            title: "Tiki Bar",
            url: "/tiki-bar",
          },
          {
            title: "Central",
            url: "/central",
          },
          {
            title: "Central café",
            url: "/central-cafe",
          },
        ],
      },
      {
        title1: "Bars & Lounges",
        subLinks: [
          {
            title: "Sapphyr Lounge",
            url: "/sapphyr-lounge",
          },
          {
            title: "Capital Bar & Grill",
            url: "/capital-bar-n-grill",
          },
          {
            title: "Pool Bar",
            url: "/pool-bar",
          },
          {
            title: "Tiki Bar",
            url: "/tiki_bar",
          },
        ],
      },
    ],
  },
  {
    title: "EXPERIENCE",
    links: [
      {
        title1: "For Kids",
        subLinks: [
          { title: "Overview", url: "/for-kid" },
          {
            title: "Adventure Zone",
            url: "/adventure",
          },
          {
            title: "Celebrations",
            url: "/celebrations",
          },
        ],
      },
      {
        title1: "Health & Leisure",
        subLinks: [
          { title: "Overview", url: "/c" },
          {
            title: "Health Club",
            url: "/health-club",
          },
          {
            title: "Chi, The Spa",
            url: "/chi-the",
          },
        ],
      },
    ],
  },
  {
    title: "EVENTS",
    links: [
      {
        title1: "Meetings & Events",
        subLinks: [
          { title: "Overview", url: "/Meetings" },
          {
            title: "Experience It",
            url: "/experience-it",
          },
          {
            title: "Coworking Space",
            url: "/coworking-space",
          },
          {
            title: "Outside Catering",
            url: "/outside",
          },
          {
            title: "Request For Proposal",
            url: "/request",
          },
          {
            title: "Book Meeting Room Online",
            url: "/Book",
          },
        ],
      },
      {
        title1: "Wedding and Celebrations",
        subLinks: [
          {
            title: "Overview",
            url: "/Overview3",
          },
          {
            title: "Wedding Planning",
            url: "/wedding-planning",
          },
          {
            title: "Weddings By Shangri-La",
            url: "/weddingsby",
          },
          {
            title: "Request for Proposal",
            url: "/request",
          },
        ],
      },
    ],
  },
  {
    title: "GALLERY",
    links: [], // Add links for the gallery section if needed
  },
  {
    title: "OFFERS",
    links: [], // Add links for the offers section if needed
  },
  {
    title: "MORE",
    links: [
      {
        title1: "Apartments",
        subLinks: [
          {
            title: "Learn More",
            url: "/LearnMore",
          },
        ],
      },
    ],
  },
];

const Navbar = () => {
  const [activeMainLink, setActiveMainLink] = useState(null);

  const handleMainLinkClick = (index) => {
    setActiveMainLink(index === activeMainLink ? null : index);
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark ">
        <div className="container">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              {NavbarData.map((item, index) => (
                <li className="nav-item" key={item.title}>
                  <Link
                    className="nav-link"
                    // to={
                    //   item.links &&
                    //   item.links[0] &&
                    //   item.links[0].subLinks &&
                    //   item.links[0].subLinks[0] &&
                    //   item.links[0].subLinks[0].url
                    // }
                    onClick={() => handleMainLinkClick(index)}
                  >
                    <span>
                      {item.title}
                      <i className="bi bi-caret-down"></i>
                    </span>
                  </Link>
                  {activeMainLink === index && (
                    <SubLinks
                      item={item}
                      activeMainLink={activeMainLink}
                      index={index}
                    />
                  )}
                </li>
              ))}
              <li className="nav-item">
                <Link
                  className="nav-link  b"
                  to={"/"}
                  tabIndex="-1"
                  aria-disabled="true"
                >
                  Find a Hotel
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
