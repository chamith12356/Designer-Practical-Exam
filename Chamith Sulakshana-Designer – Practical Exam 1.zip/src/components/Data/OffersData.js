const OfferData = [
  {
    imageUrl:
      "https://img.freepik.com/free-photo/pillow-bed_74190-1990.jpg?w=996&t=st=1707990964~exp=1707991564~hmac=308e673e25e72a92b739a66013db5290a08636cd5e5305a802a35089d961b936",
    title: "Rooms & Suites",
    description1: "Carlton Circle Exclusive Member Rate with Breakfast",
    description2:
      "Exclusive Member Rate with Breakfast for Carlton Circle member",
  },
  {
    imageUrl:
      "https://plus.unsplash.com/premium_photo-1675745329954-9639d3b74bbf?auto=format&fit=crop&q=80&w=1887&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    title: "Family Suites",
    description1: "Carlton Circle Exclusive Member Rate",
    description2: "Exclusive Member Rate for Carlton hotel Circle member.",
  },
  {
    imageUrl:
      "https://img.freepik.com/free-photo/bokeh-defocused-gold-abstract-christmas-background_1232-1804.jpg?w=996&t=st=1707991056~exp=1707991656~hmac=6db1d83a9ceb8275f8c7d5e31630921a1bbfef8e5be1161930e0ff226b5f2b74",
    title: "Seasonal Events",
    description1: "Celebrate the Spirit of Negroni at Capital Bar & Grill",
    description2:
      "Raise your glass to honour an icon that has taken over bars all over the world.",
  },
];
export default OfferData;
