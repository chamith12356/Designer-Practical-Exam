const ExperienceData = [
  {
    imageUrl:
      "https://img.freepik.com/free-photo/relax-woman-jumping-sea-beach_1249-567.jpg?w=996&t=st=1707990436~exp=1707991036~hmac=d05491600507ebce3742f89a75c44c9366272d62539b4fc7621e41c8b183fd2c",
    text: "MULTIPLE YOUR TIME",
  },
  {
    imageUrl:
      "https://img.freepik.com/free-photo/abstract-blur-coffee-shop-cafe_1203-7981.jpg?w=996&t=st=1707990530~exp=1707991130~hmac=b357d54ce68f0b9a1222b29f01478fe649b137942cfed9ee3573a3d367054407",
    text: "Free Bonus Points at new hotels",
  },
  {
    imageUrl:
      "https://images.unsplash.com/photo-1556742031-c6961e8560b0?auto=format&fit=crop&q=80&w=1964&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    text: " DISCOUNT - SAVE UP TO 17%",
  },
  {
    imageUrl:
      "https://img.freepik.com/free-photo/outdoor-swimming-pool_1203-3241.jpg?w=360&t=st=1707990651~exp=1707991251~hmac=bf1b117e2c653557b2747c8b6c9eaed525f24a3321b2f2aec2334224efe51804",
    text: "Join Hilton Honors Get Up to 4,500 Points",
  },
  {
    imageUrl:
      "https://img.freepik.com/free-photo/bench-tree_107420-95706.jpg?w=360&t=st=1707990725~exp=1707991325~hmac=5ddded3e4fc8fd8deceb283d524eb0f8e9caeeea523510ed5e9d8b5b73a4adcf",
    text: "Park & Stay",
  },
  {
    imageUrl:
      "https://plus.unsplash.com/premium_photo-1686316978658-81df4c96d757?auto=format&fit=crop&q=80&w=1936&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    text: "Experience the Stay",
  },
];
export default ExperienceData;
