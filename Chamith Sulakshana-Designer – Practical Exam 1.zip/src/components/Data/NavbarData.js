const NavbarData = {
  MainLink: [
    { text: "Home", link: "/" },
    { text: "About", link: "/about" },
    { text: "Rooms", link: "/rooms" },
    { text: "Dining", link: "/dining" },
    { text: "Experience", link: "/experience" },
    { text: "Events", link: "/events" },
    { text: "Gallery", link: "/gallery" },
    { text: "Offers", link: "/offers" },
  ],
  SubLink: [
    { text: "Home", link: "/" },
    { text: "About", link: "/about" },
    { text: "Rooms", link: "/rooms" },
    { text: "Dining", link: "/dining" },
    { text: "Experience", link: "/experience" },
    { text: "Events", link: "/events" },
    { text: "Gallery", link: "/gallery" },
    { text: "Offers", link: "/offers" },
  ],
};
export default NavbarData;
