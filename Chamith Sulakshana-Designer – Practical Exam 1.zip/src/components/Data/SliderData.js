const SliderData = [
  {
    imageSrc:
      "https://img.freepik.com/free-photo/beautiful-umbrella-chair-around-swimming-pool-hotel-resort_74190-1006.jpg?w=996&t=st=1707985982~exp=1707986582~hmac=68e723e45035fd8d066631606e1ac3ac2362eaa0c700957ea39711ef11e7e88f",
    title: "Carlton Hotel Sri Lanka",
    content: "Most Populer Hotel In the Sri Lanka.",
  },
  {
    imageSrc:
      "https://img.freepik.com/free-photo/sharm-blue-travel-vacation-white_1203-4810.jpg?w=996&t=st=1707986284~exp=1707986884~hmac=dd9af7d0e1c3c8f5c6787c346490aad20f2d49f4306f924b0d8b8c34b38cf0e6",
    title: "Carlton Hotel ",
    content:
      "Come with us through the whimsical world of Carlton, where your personal paradise awaits..",
  },
  {
    imageSrc:
      "https://img.freepik.com/free-photo/elegant-hotel-room-with-big-bed_1203-1494.jpg?w=996&t=st=1707985561~exp=1707986161~hmac=1705949f037e8388ca9bd6a767ca1f1ca7b148e5c42f2c3c25c14f176fe343ca",
    title: "Rooms & Suites",
    content: "Tastefully designed with the modern traveler in mind.",
  },
  {
    imageSrc:
      "https://img.freepik.com/free-photo/banquet-table-with-snacks_144627-18361.jpg?w=996&t=st=1707985605~exp=1707986205~hmac=ef8de6cf8e8d0a0c72ae5f0d8977c7b8bb1c093d3a350b1f5c8d37e459d696d2",
    title: "Carlton Restaurant",
    content: "Celebrate the art of Chinese cuisine in the heart of Sri Lanka.",
  },
];
export default SliderData;
