const FooterData = {
  aboutLinks: [
    { text: "Home", href: "/home" },
    { text: "About Us", href: "/" },
    { text: "Rooms & Suites", href: "/" },
    { text: "Dining", href: "/" },
    { text: "Experience", href: "/" },
    { text: "Events", href: "/" },
    { text: "Gallery", href: "/" },
    { text: "Offer", href: "/" },
  ],
  contactLinks: [
    { text: "Know Sri Lanka", href: "/" },
    { text: "Contact Us", href: "/" },
    { text: "FAQs", href: "/" },
  ],
  sectionsLinks: [
    { text: "Careers", href: "/" },
    { text: "Blog", href: "/" },
  ],
};
export default FooterData;
