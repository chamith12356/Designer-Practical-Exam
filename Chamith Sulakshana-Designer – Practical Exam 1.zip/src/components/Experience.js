import React from "react";
import Offers from "./Offers";
import "./ExperienceStyle.css";
import ExperienceData from "./Data/ExperienceData";
export default function Experience() {
  // Sample data for your cards

  // Create cards with data

  const cards = ExperienceData.map((card, index) => (
    <div className="col-md-4 col-sm-4 col-lg-4 col-12 " key={index}>
      <div className="card" id="ecard">
        <img
          id="eimg1"
          src={card.imageUrl}
          alt={card.text}
          className="card-img-top"
        />
        <div className="card-body">
          <p className="card-text" id="ecardbody">
            {card.text}
          </p>
        </div>
      </div>
    </div>
  ));

  // Split cards into rows of three
  const rows = [];
  for (let i = 0; i < cards.length; i += 3) {
    rows.push(
      <div className="row" key={i}>
        {cards.slice(i, i + 3)}
      </div>
    );
  }

  return (
    <div>
      <div className="row">
        <div className="col-12 col-sm-12 col-md-12 col-lg-12">
          <h2 id="hd">Experience Something New</h2>
          <p id="ph">
            Fall into a relaxing stay with one of our exclusive offers.
          </p>
        </div>
      </div>

      <div class="container"> {rows}</div>
      <Offers />
    </div>
  );
}
