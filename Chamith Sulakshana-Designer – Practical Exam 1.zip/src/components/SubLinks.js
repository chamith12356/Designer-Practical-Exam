import React from "react";
import { Link } from "react-router-dom";

const SubLinks = ({ item, activeMainLink, index }) => {
  return (
    <div className="row sub">
      {activeMainLink === index &&
        item.links &&
        item.links.map((linkItem, linkIndex) => (
          <ul className="col-md-3 sub1" key={linkIndex}>
            <h5>
              <u>{linkItem.title1}</u>
            </h5>{" "}
            {/* Access title1 from linkItem */}
            {linkItem.subLinks.map((subItem, subIndex) => (
              <li className="nav-item sub2" key={subIndex}>
                <Link className="nav-link sub3" to={subItem.url}>
                  {subItem.title}
                </Link>
              </li>
            ))}
          </ul>
        ))}
    </div>
  );
};

export default SubLinks;
