import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./HeaderStyle.css";
// import Navbar1 from "./Navbar1";
// import "./../CSS/mobile.css";

import { Link } from "react-router-dom";

export default function Header() {
  return (
    <div>
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-4 col-md-4 col-sm-4 col-12">
            <div className="header">
              <Link className="head" to={"/"}>
                <img
                  className="logo"
                  src="
                  https://www.pngitem.com/pimgs/m/361-3614092_carlton-hotel-logo-logo-carlton-international-hd-png.png"
                  alt="logo"
                />
              </Link>
            </div>
          </div>
          <div className="col-lg-8 col-md-8 col-sm-8 col-12">
            <div className="headerfirst">
              <Link className="head" to={"/Sing"}>
                <i className="bi bi-person"></i>&nbsp;Sing In &nbsp;|
              </Link>
              <Link className="head" to={"/JoinNow"}>
                Join Now &nbsp;|
              </Link>
              <Link className="head" to={"/ForReservation"}>
                For Reservation &nbsp; |
              </Link>
              <Link className="head" to={"/English"}>
                <i className="bi bi-globe"></i>&nbsp;English &nbsp;|
              </Link>
              <Link className="head" to={"/LKR"}>
                LKR <i className="bi bi-phone"></i>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
