import React from "react";
import "./SliderStyle.css";
import SliderData from "./Data/SliderData";
import Destinations from "./Destinations";
import NewItem from "./NewItem";
import SecondItem from "./SecondItem";

export default function Slider() {
  return (
    <div>
      <div
        id="carouselExampleControls"
        className="carousel slide"
        data-bs-ride="carousel"
      >
        <div className="carousel-inner">
          {SliderData.map((slide, index) => (
            <div
              key={index}
              className={`carousel-item ${index === 0 ? "active" : ""}`}
            >
              <img
                src={slide.imageSrc}
                className="d-block w-100"
                alt={`Slide ${index + 1}`}
              />
              <div className="carousel-caption text-center">
                <h1>{slide.title}</h1>
                <p>{slide.content}</p>
              </div>
            </div>
          ))}
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleControls"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleControls"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      <div>
        <div className="container">
          <div className="row">
            <div className="col-12 col-md-10 col-sm-10 col-lg-10 mx-auto bg-white shadow p-2 rounded">
              <form>
                <div className="row">
                  <div className="col-sm-3 col-md-3 col-lg-3 col-12 mb-2">
                    <input
                      type="date"
                      id="date"
                      className="form-control shadow-none"
                    />
                  </div>
                  <div className=" col-sm-3 col-md-3 col-lg-3  col-12 mb-2">
                    <input
                      type="date"
                      id="date"
                      className="form-control shadow-none"
                    />
                  </div>
                  <div className=" col-sm-2 col-md-2 col-lg-2 col-12 mb-2">
                    <NewItem />
                  </div>
                  <div className="col-sm-2 col-md-2 col-lg-2 col-12 mb-2">
                    <SecondItem />
                  </div>
                  <div className=" col-sm-2 col-md-2 col-lg-2 col-12 mb-2">
                    <button type="submit" className="btn btn-primary ">
                      Search
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <Destinations />
    </div>
  );
}
