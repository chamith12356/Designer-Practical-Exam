import React from "react";
import Footer from "./Footer";
import "./OffersStyle.css";
import OfferData from "./Data/OffersData";
export default function Offers() {
  // Sample data for your cards

  // Create cards with data
  const cards = OfferData.map((card, index) => (
    <div className="col-lg-4 col-md-4 col-sm-4 col-12" key={index}>
      <div className="card" id="cardoffer1">
        <img
          src={card.imageUrl}
          alt={card.title}
          id="nimg"
          className="card-img-top"
        />
        <div className="card-body">
          <h4 className="card-title" id="ntitle">
            {card.title}
          </h4>
          <p className="card-text" id="ncard">
            {card.description1}
          </p>
          <p className="card-text" id="ntext">
            {card.description2}
          </p>
          <button id="nbtn">View Details</button>
        </div>
      </div>
    </div>
  ));

  return (
    <div>
      <div className="container">
        <div className="row">
          <h3>Offer</h3>
          {cards}
        </div>
      </div>
      <Footer />
    </div>
  );
}
