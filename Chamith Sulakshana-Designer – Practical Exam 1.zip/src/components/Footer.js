import React from "react";
import "./FooterStyle.css";
import { useState } from "react";
import FooterData from "./Data/FooterData";
import { Link } from "react-router-dom";
export default function Footer() {
  const [scrolledDown, setScrolledDown] = useState(false);

  // Function to handle scrolling to the top of the page
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Event listener to check if the user has scrolled down
  window.addEventListener("scroll", () => {
    if (window.scrollY > 100) {
      // User has scrolled down, show the scroll-up button
      setScrolledDown(true);
    } else {
      // User is at the top of the page, hide the scroll-up button
      setScrolledDown(false);
    }
  });
  return (
    <div>
      <footer className="footer">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-4 col-lg-4 col-12 col-sm-4">
              <h3 className="ih new">About</h3>

              <ul>
                {FooterData.aboutLinks.map((link, index) => (
                  <li key={index} className="ii">
                    <Link className="ia" to={link.href}>
                      {link.text}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-md-4 col-lg-4 col-12 col-sm-4">
              <h3 className="ih">Get in Touch</h3>
              <ul>
                {FooterData.contactLinks.map((link, index) => (
                  <li key={index} className="iin">
                    <Link className="ia" to={link.href}>
                      {link.text}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="ihi">Sections</h3>
              <ul>
                {FooterData.sectionsLinks.map((link, index) => (
                  <li key={index} className="iin">
                    <Link className="ia" to={link.href}>
                      {link.text}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="col-md-4 col-lg-4 col-12 col-sm-4">
              <h3 className="ihv1">Follow Us</h3>
              <ul className="lu">
                <li className="iii">
                  <Link className="ia" to={"/"}>
                    <i className="bi bi-facebook"></i>
                  </Link>
                </li>
                <li className="iii">
                  <Link className="ia" to={"/"}></Link>
                  <i className="bi bi-instagram"></i>
                </li>
                <li className="iii">
                  <Link className="ia" to={"/"}></Link>
                  <i className="bi bi-twitter"></i>
                </li>
                <li className="iii">
                  <Link className="ia" to={"/"}></Link>
                  <i className="bi bi-youtube"></i>
                </li>
                <li className="iii">
                  {" "}
                  {scrolledDown && (
                    <button
                      className="scroll-up-button"
                      onClick={handleScrollToTop}
                    >
                      <i className="bi bi-chevron-double-up"></i>
                    </button>
                  )}
                </li>
              </ul>

              <h3 className="ihv">Get Carlton In</h3>
              <input
                id="input"
                type="text"
                className="form-control"
                placeholder="Enter your email"
              />
              <p className="lp">Subscribe to our newsletter for updates.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
