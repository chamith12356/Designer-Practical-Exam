import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Home from "./Home";
import PremierOceanView from "./routes/PremierOceanView";
import PremierBalcony from "./routes/PremierBalcony";
import DeluxeOceanView from "./routes/DeluxeOceanView";
import DeluxeLakeView from "./routes/DeluxeLakeView";
import ExploreColombo from "./routes/ExploreColombo";
import Overview from "./routes/Overview";
import Services from "./routes/Services";
import "./styles.css";
import Map1 from "./routes/Map1";
import HorizonLakeView from "./routes/HorizonLakeView";
import HorizonOceanView from "./routes/HorizonOceanView";
import ExecutiveSuites from "./routes/ExecutiveSuites";
import SpecialtySuites from "./routes/SpecialtySuites";
import ExecutiveSuitePremier from "./routes/ExecutiveSuitePremier";
import TwoDeluxeLake from "./routes/TwoDeluxeLake";
import CakeTemptations from "./routes/CakeTemptations";
import ShangPalace from "./routes/ShangPalace";
import CapitalBar from "./routes/CapitalBar";
import TikiBar from "./routes/TikiBar";
import TikiBar1 from "./routes/TikiBar1";
import Central from "./routes/Central";
import Centralcafé from "./routes/Centralcafé";
import SapphyrLounge from "./routes/SapphyrLounge";
import CapitalBarGrill from "./routes/CapitalBarGrill";
import PoolBar from "./routes/PoolBar";
import Overviewkid from "./routes/Overviewkid";
import Adventure from "./routes/Adventure";
import Celebrations from "./routes/Celebrations";
import Overviewhelath from "./routes/Overviewhelath";
import ExperienceIt from "./routes/ExperienceIt";
import Meetings from "./routes/Meetings";
import ChiThe from "./routes/ChiThe";
import Coworking from "./routes/Coworking";
import Outside from "./routes/Outside";
import Request from "./routes/Request";
import Book from "./routes/Book";
import Overview3 from "./routes/Overview3";
import Planning from "./routes/Planning";
import Weddings from "./routes/Weddings";
import Request1 from "./routes/Request1";
import Learn from "./routes/Learn";
import Weddingsby from "./routes/Weddingsby";
import healthclub from "./routes/healthclub";
export default function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about/Overview" element={<Overview />} />
        <Route path="/about/local-guide" element={<ExploreColombo />} />
        <Route path="/about/services-facilities/" element={<Services />} />
        <Route path="/about/map" element={<Map1 />} />
        <Route path="/deluxe-lake-view-room" element={<DeluxeLakeView />} />
        <Route path="/deluxe-ocean-view-room" element={<DeluxeOceanView />} />
        <Route path="/premier-balcony-room" element={<PremierBalcony />} />
        <Route path="/premier-ocean-view-room" element={<PremierOceanView />} />
        <Route path="/horizonlake-view" element={<HorizonLakeView />} />
        <Route path="/horizonocean-view" element={<HorizonOceanView />} />
        <Route path="/executive-suites" element={<ExecutiveSuites />} />
        <Route path="/specialty-suites" element={<SpecialtySuites />} />
        <Route path="/shangrila-suite" element={<SpecialtySuites />} />
        <Route path="/horizonlake-view" element={<HorizonLakeView />} />
        <Route path="/executive-suite" element={<ExecutiveSuitePremier />} />
        <Route path="/two-deluxe-lake" element={<TwoDeluxeLake />} />
        <Route path="/cake-temptations" element={<CakeTemptations />} />
        <Route path="/shang-palace" element={<ShangPalace />} />
        <Route path="/capital-bar" element={<CapitalBar />} />
        <Route path="/tiki-bar" element={<TikiBar />} />
        <Route path="/central" element={<Central />} />
        <Route path="/central-cafe" element={<Centralcafé />} />
        <Route path="/sapphyr-lounge" element={<SapphyrLounge />} />
        <Route path="/capital-bar-n-grill" element={<CapitalBarGrill />} />
        <Route path="/pool-bar" element={<PoolBar />} />
        <Route path="/tiki_bar" element={<TikiBar1 />} />
        <Route path="/for-kid" element={<Overviewkid />} />
        <Route path="/adventure" element={<Adventure />} />
        <Route path="/celebrations" element={<Celebrations />} />
        <Route path="/c" element={<Overviewhelath />} />
        <Route path="/health-club" element={<Overviewhelath />} />
        <Route path="/chi-the" element={<ChiThe />} />
        <Route path="/Meetings" element={<Meetings />} />
        <Route path="/experience-it" element={<ExperienceIt />} />
        <Route path="/coworking-space" element={<Coworking />} />
        <Route path="/outside" element={<Outside />} />
        <Route path="/request" element={<Request />} />
        <Route path="/Book" element={<Book />} />
        <Route path="/Overview3" element={<Overview3 />} />
        <Route path="/wedding-planning" element={<Planning />} />
        <Route path="/weddingsby" element={<Weddingsby />} />
        <Route path="/weddings" element={<Weddings />} />
        <Route path="/request" element={<Request1 />} />
        <Route path="/LearnMore" element={<Learn />} />
      </Routes>
    </div>
  );
}
